SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[Proc_CMS_Email_BindAttachment]
    @EmailID int,
    @Name nvarchar(255),
    @Ext nvarchar(50),
    @Size int,
    @MimeType nvarchar(100),
    @Bin image,
	@ContentID nvarchar(255),
	@GUID uniqueidentifier,
    @LastModified datetime2(7),
	@SiteID int
AS
BEGIN
    SET NOCOUNT ON

	DECLARE @AttID int
	SET @AttID = 0

	/* Search for attachment with specified parameters */
	SELECT @AttID = AttachmentID FROM CMS_EmailAttachment WHERE
		ISNULL(AttachmentSiteID, 0) = ISNULL(@SiteID, 0) AND AttachmentSize = @Size AND
		AttachmentGUID = @GUID AND AttachmentName = @Name AND AttachmentExtension = @Ext AND
		AttachmentMimeType = @MimeType AND ISNULL(AttachmentContentID, '') = ISNULL(@ContentID, '')

	IF @AttID > 0
	  BEGIN
		/* Bind attachment to e-mail */
		IF (SELECT COUNT(1) FROM [CMS_AttachmentForEmail] WHERE EmailID = @EmailID AND AttachmentID = @AttID) = 0
		  BEGIN
			INSERT INTO [CMS_AttachmentForEmail] ([EmailID], [AttachmentID]) VALUES (@EmailID, @AttID)
		  END
	  END
	ELSE
	  BEGIN
		BEGIN TRANSACTION

		/* Create record for attachment */
		INSERT INTO [CMS_EmailAttachment] ([AttachmentName], [AttachmentExtension], [AttachmentSize], [AttachmentMimeType],
			[AttachmentBinary], [AttachmentGUID], [AttachmentLastModified], [AttachmentContentID], [AttachmentSiteID])
			VALUES (@Name, @Ext, @Size, @MimeType, @Bin, @GUID, @LastModified, @ContentID, @SiteID)
		SET @AttID = SCOPE_IDENTITY()

		/* Bind attachment to e-mail */
		INSERT INTO [CMS_AttachmentForEmail] ([EmailID], [AttachmentID]) VALUES (@EmailID, @AttID)

		COMMIT TRANSACTION
	  END

	SELECT @AttID
END
GO
