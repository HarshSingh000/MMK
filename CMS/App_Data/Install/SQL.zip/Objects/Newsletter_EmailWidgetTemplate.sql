SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Newsletter_EmailWidgetTemplate](
	[EmailWidgetTemplateID] [int] IDENTITY(1,1) NOT NULL,
	[EmailWidgetID] [int] NOT NULL,
	[TemplateID] [int] NOT NULL,
 CONSTRAINT [PK_Newsletter_EmailWidgetTemplate] PRIMARY KEY CLUSTERED 
(
	[EmailWidgetTemplateID] ASC
)
)
GO
CREATE NONCLUSTERED INDEX [IX_Newsletter_EmailWidgetTemplate_EmailWidgetID] ON [dbo].[Newsletter_EmailWidgetTemplate]
(
	[EmailWidgetID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_Newsletter_EmailWidgetTemplate_TemplateID] ON [dbo].[Newsletter_EmailWidgetTemplate]
(
	[TemplateID] ASC
)
GO
ALTER TABLE [dbo].[Newsletter_EmailWidgetTemplate] ADD  CONSTRAINT [DEFAULT_Newsletter_EmailWidgetTemplate_EmailWidgetID]  DEFAULT ((0)) FOR [EmailWidgetID]
GO
ALTER TABLE [dbo].[Newsletter_EmailWidgetTemplate] ADD  CONSTRAINT [DEFAULT_Newsletter_EmailWidgetTemplate_TemplateID]  DEFAULT ((0)) FOR [TemplateID]
GO
ALTER TABLE [dbo].[Newsletter_EmailWidgetTemplate]  WITH CHECK ADD  CONSTRAINT [FK_Newsletter_EmailWidgetTemplate_EmailWidgetID_Newsletter_EmailWidget] FOREIGN KEY([EmailWidgetID])
REFERENCES [dbo].[Newsletter_EmailWidget] ([EmailWidgetID])
GO
ALTER TABLE [dbo].[Newsletter_EmailWidgetTemplate] CHECK CONSTRAINT [FK_Newsletter_EmailWidgetTemplate_EmailWidgetID_Newsletter_EmailWidget]
GO
ALTER TABLE [dbo].[Newsletter_EmailWidgetTemplate]  WITH CHECK ADD  CONSTRAINT [FK_Newsletter_EmailWidgetTemplate_TemplateID_Newsletter_EmailTemplate] FOREIGN KEY([TemplateID])
REFERENCES [dbo].[Newsletter_EmailTemplate] ([TemplateID])
GO
ALTER TABLE [dbo].[Newsletter_EmailWidgetTemplate] CHECK CONSTRAINT [FK_Newsletter_EmailWidgetTemplate_TemplateID_Newsletter_EmailTemplate]
GO
